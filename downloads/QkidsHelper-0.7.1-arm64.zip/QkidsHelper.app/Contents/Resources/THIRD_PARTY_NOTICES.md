# 第三方组件

发布包包含以下开源模型与运行环境。各自的许可证仍然适用。

| 组件 | 来源 | 许可 |
| --- | --- | --- |
| faster-whisper-small | https://huggingface.co/Systran/faster-whisper-small | MIT |
| Qwen3-4B，Ollama 量化版本 qwen3:4b | https://huggingface.co/Qwen/Qwen3-4B | Apache-2.0 |
| Ollama 及推理组件 | https://github.com/ollama/ollama | MIT 及随附第三方许可 |
| CPython 3.12 | https://www.python.org/ | Python Software Foundation License |
| Python 依赖 | engine/requirements.lock.txt | 各软件包自带的许可证 |
| Sparkle 2.10.1 | https://github.com/sparkle-project/Sparkle | MIT 及随附第三方许可；见应用 Resources/Sparkle-LICENSE.txt |

模型许可证保存在 Offline/licenses；Ollama 各组件的 LICENSE、NOTICE 随引擎保留；Python 包许可证保存在各自的 dist-info 或相应包目录。模型版本、文件大小和 SHA-256（文件校验值）保存在 Offline/manifest.json。

头像为此项目生成的猫头鹰插画。本项目不隶属于 Qkids，也没有 Qkids 的授权或背书。
