#!/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ACTION="${1:?missing action}"
DATA="${2:?missing data directory}"
shift 2
OFFLINE="${QKIDS_OFFLINE_PATH:-$HERE/../Offline}"
PYTHON="$OFFLINE/runtime/python/bin/python3.12"
if [ ! -x "$PYTHON" ]; then
  echo '安装包不完整：缺少内置运行环境。请重新解压完整安装包。'; exit 1
fi
if [ "$(uname -m)" != arm64 ]; then
  echo '此离线包适用于 Apple 芯片 Mac（M1 及后续机型），不适用于 Intel Mac。'; exit 1
fi
mkdir -p "$DATA/runtime"
export QKIDS_DATA_DIR="$DATA"
export QKIDS_ASR_MODEL_PATH="$OFFLINE/models/asr"
export QKIDS_OLLAMA_MODELS="$OFFLINE/models/review"
export QKIDS_OLLAMA_BIN="$OFFLINE/runtime/ollama/ollama"
export HF_HUB_OFFLINE=1 HF_HUB_DISABLE_TELEMETRY=1 DO_NOT_TRACK=1
export OLLAMA_NO_CLOUD=1 PYTHONUNBUFFERED=1
exec "$PYTHON" -I -B -u "$HERE/pipeline.py" "$ACTION" "$@"
